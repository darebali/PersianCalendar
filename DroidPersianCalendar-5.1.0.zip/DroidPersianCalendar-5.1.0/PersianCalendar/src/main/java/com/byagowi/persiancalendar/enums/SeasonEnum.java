package com.byagowi.persiancalendar.enums;

public enum SeasonEnum {
    SPRING,
    SUMMER,
    FALL,
    WINTER
}
