package com.byagowi.persiancalendar.enums;

/**
 * Calendars Types
 *
 * @author ebraminio
 */
public enum CalendarTypeEnum {
    SHAMSI, ISLAMIC, GREGORIAN
}
